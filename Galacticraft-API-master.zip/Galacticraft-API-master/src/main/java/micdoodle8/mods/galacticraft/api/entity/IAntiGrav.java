package micdoodle8.mods.galacticraft.api.entity;

/**
 * Implement into entities that are unaffected by gravity
 */
public interface IAntiGrav
{
}
