package micdoodle8.mods.galacticraft.api.transmission;

public enum NetworkType
{
    OXYGEN,
    POWER,
    HYDROGEN
}
