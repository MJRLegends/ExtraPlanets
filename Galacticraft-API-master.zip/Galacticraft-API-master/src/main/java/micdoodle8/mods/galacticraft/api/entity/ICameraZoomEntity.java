package micdoodle8.mods.galacticraft.api.entity;

public interface ICameraZoomEntity
{
    public float getCameraZoom();

    public boolean defaultThirdPerson();
}
