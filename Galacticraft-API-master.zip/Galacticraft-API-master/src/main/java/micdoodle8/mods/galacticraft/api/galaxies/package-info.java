@API(apiVersion = "1.3", owner = "GalacticraftCore", provides = "Galacticraft API") package micdoodle8.mods.galacticraft.api.galaxies;

import cpw.mods.fml.common.API;

