package micdoodle8.mods.galacticraft.api.world;

public enum IAtmosphericGas
{
    NITROGEN,
    OXYGEN,
    CO2,
    WATER,
    METHANE,
    HYDROGEN,
    HELIUM,
    ARGON
}

