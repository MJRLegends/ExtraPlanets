package micdoodle8.mods.galacticraft.api.entity;

import net.minecraft.world.World;

public interface IWorldTransferCallback
{
    public void onWorldTransferred(World world);
}
