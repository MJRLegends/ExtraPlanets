package micdoodle8.mods.galacticraft.api.galaxies;

public interface IChildBody
{
    Planet getParentPlanet();
}
