@API(apiVersion = "1.1", owner = "GalacticraftCore", provides = "Galacticraft API") package micdoodle8.mods.galacticraft.api.event.client;

import cpw.mods.fml.common.API;

