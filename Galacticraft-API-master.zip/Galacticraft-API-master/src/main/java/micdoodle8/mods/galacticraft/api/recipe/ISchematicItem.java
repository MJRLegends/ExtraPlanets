package micdoodle8.mods.galacticraft.api.recipe;

/**
 * Implement this in an item that will be accepted into the schematic slot
 */
public interface ISchematicItem
{

}
