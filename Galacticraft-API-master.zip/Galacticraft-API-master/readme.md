Galacticraft-API
============

API for the Galacticraft mod.

Main Project:
https://github.com/micdoodle8/Galacticraft/
 
License
=======

License can be found here: https://github.com/micdoodle8/Galacticraft-API/blob/master/LICENSE.txt
